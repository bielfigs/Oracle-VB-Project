define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class saveDepartmentChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;

      // Sets the progress variable to true
      $page.variables.saveDepartmentChainInProgress = true;

      // Validates Department form
      const validateFormResult = await Actions.callChain(context, {
        chain: 'flow:validateFormChain',
        params: {
          validationGroupId: 'validation-group',
        },
      });

      if (validateFormResult === true) {
        const callRestSaveDepartmentResult = await Actions.callRest(context, {
          endpoint: 'businessObjects/update_Department',
          body: $page.variables.department,
          uriParams: {
            'Department_Id': $page.variables.departmentId,
          },
        }, { id: 'saveDepartment' });

        if (callRestSaveDepartmentResult.ok) {
          $page.variables.department = callRestSaveDepartmentResult.body;
          $page.variables.departmentETag = callRestSaveDepartmentResult.headers.get('ETag');

          await Actions.fireNotificationEvent(context, {
            summary: 'Department saved',
            message: 'Department record successfully updated',
            displayMode: 'transient',
            type: 'confirmation',
          }, { id: 'fireSuccessNotification' });

          await Actions.navigateBack(context, {
          }, { id: 'navigateBack' });
        } else {
          // Create error message
          const errorMessage = callRestSaveDepartmentResult.body?.['o:errorDetails']?.[0]?.detail ||
                               `Could not update Department: status ${callRestSaveDepartmentResult.status}`;
          // Fires a notification event about failed save
          await Actions.fireNotificationEvent(context, {
              summary: 'Save failed',
              message: errorMessage,
          }, { id: 'fireErrorNotification' });
        }
      }

      // Sets the progress variable to false
      $page.variables.saveDepartmentChainInProgress = false;
    }
  }

  return saveDepartmentChain;
});
