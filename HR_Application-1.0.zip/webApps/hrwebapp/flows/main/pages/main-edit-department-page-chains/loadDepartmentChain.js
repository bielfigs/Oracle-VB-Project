define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class loadDepartmentChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;

      const callRestGetDepartmentResult = await Actions.callRest(context, {
        endpoint: 'businessObjects/get_Department',
        responseType: 'getDepartmentResponse',
        uriParams: {
          'Department_Id': $page.variables.departmentId,
        },
      }, { id: 'loadDepartment' });

      if (callRestGetDepartmentResult.ok) {
        $page.variables.department = callRestGetDepartmentResult.body;
        $page.variables.departmentETag = callRestGetDepartmentResult.headers.get('ETag');
      } else {
        // Create error message
        const errorMessage = callRestGetDepartmentResult.body?.['o:errorDetails']?.[0]?.detail ||
                             `Could not load data: status ${callRestGetDepartmentResult.status}`;
        // Fires a notification event about failed load
        await Actions.fireNotificationEvent(context, {
          summary: 'Could not load data',
          message: errorMessage,
        }, { id: 'fireErrorNotification' });
      }
    }
  }

  return loadDepartmentChain;
});
